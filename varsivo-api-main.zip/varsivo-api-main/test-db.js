require('dotenv').config();
const { testConnection, getPool, sql } = require('./src/config/database');

(async () => {
  console.log('Testing Azure SQL connection...');
  console.log('Server:', process.env.DB_SERVER);
  console.log('Database:', process.env.DB_DATABASE);
  console.log('User:', process.env.DB_USER);
  console.log('');

  const ok = await testConnection();

  if (ok) {
    console.log('✅ Connection successful');

    // Check if users table exists
    try {
      const pool = await getPool();
      const result = await pool.request().query(`
        SELECT COUNT(*) AS cnt
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_NAME = 'users'
      `);
      const hasUsersTable = result.recordset[0].cnt > 0;
      console.log('Users table exists:', hasUsersTable ? '✅' : '❌ (needs creating)');
    } catch (err) {
      console.log('Could not check tables:', err.message);
    }
  } else {
    console.log('❌ Connection failed');
  }

  process.exit(0);
})();