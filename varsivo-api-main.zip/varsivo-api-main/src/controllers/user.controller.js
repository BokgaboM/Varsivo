const userStore = require('../services/userStore');

/**
 * GET /api/users/me
 * Requires auth — req.user.uid is set by the auth middleware.
 *
 * Flow:
 *   1. auth middleware verified the JWT and set req.user.uid
 *   2. we fetch the user row from Azure SQL by uid (which is the DB id)
 *   3. mapRowToUser() converts snake_case columns to camelCase
 *   4. respond with the safe user object + academic profile
 */


exports.getMe = async (req, res, next) => {
  try {
    const row = await userStore.findById(req.user.uid);

    if (!row) {
      return res.status(404).json({ error: 'User not found' });
    }

    // mapRowToUser already excludes password_hash and salt
    const user = userStore.mapRowToUser(row);

    res.json({
      user,
      academicProfile: {
        grade: null,
        yearOfStudy: null,
        subjects: [],
        apsScore: null,
      },
    });
  } catch (err) {
    next(err);
  }
};

/**
 * PATCH /api/users/:id/settings
 * Requires auth. Only the user themselves can update their own settings.
 *
 * Body (any subset):
 *   { preferredLanguage?: string, notificationsEnabled?: boolean }
 */
exports.updateSettings = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Users can only update their own settings
    if (id !== req.user.uid) {
      return res.status(403).json({ error: 'You can only update your own settings' });
    }

    const { preferredLanguage, notificationsEnabled } = req.body;

    // Validate language if provided
    if (preferredLanguage !== undefined) {
      const allowed = ['EN', 'isiZulu', 'Afrikaans'];
      if (!allowed.includes(preferredLanguage)) {
        return res.status(400).json({
          error: `preferredLanguage must be one of: ${allowed.join(', ')}`,
        });
      }
    }

    const updated = await userStore.updateSettings(id, {
      preferredLanguage,
      notificationsEnabled,
    });

    if (!updated) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userStore.mapRowToUser(updated);

    res.json({
      message: 'Settings updated',
      user,
    });
  } catch (err) {
    next(err);
  }
};