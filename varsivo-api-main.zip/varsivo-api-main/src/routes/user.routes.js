const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const userController = require('../controllers/user.controller');

router.get('/me', authenticate, userController.getMe);
router.patch('/:id/settings', authenticate, userController.updateSettings);

module.exports = router;