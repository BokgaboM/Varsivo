const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// ─── Security & Parsing Middleware ─────────────────────────────

// helmet: adds HTTP security headers (X-Frame-Options, etc.)
app.use(helmet());

// cors: allows the Android app to call this server from another origin
app.use(cors());

// express.json: parses JSON request bodies into req.body
app.use(express.json({ limit: '1mb' }));

// morgan: logs each request to the console (method, URL, status, time)
app.use(morgan('dev'));

// ─── Rate Limiting ─────────────────────────────────────────────
// Prevent abuse: max 100 requests per 15 minutes per IP
app.use('/api', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'Too many requests, please try again later.' },
}));

// ─── Health Check ──────────────────────────────────────────────
// A simple endpoint to confirm the server is running
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'varsivo-api',
    timestamp: new Date().toISOString(),
  });
});

// ─── Routes ────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);

// ─── 404 Handler ───────────────────────────────────────────────
// Any request that reaches this point didn't match a route
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// ─── Global Error Handler ──────────────────────────────────────
// Must be the LAST middleware. Handles any error thrown by controllers.
app.use(errorHandler);

// ─── Start the Server ──────────────────────────────────────────
// PORT comes from .env, falls back to 3000
// "0.0.0.0" binds to all network interfaces — needed for deployments
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Varsivo API running on port ${PORT}`);
});